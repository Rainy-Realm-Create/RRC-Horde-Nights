#================NOTE=================#
#All code made by RRC for Horde Nights#
#==Liscense for use per Modrinth TOS==#
#================NOTE=================#

execute unless score #active h-nigh.status matches 1.. run scoreboard players set #time_lib_bunk h-nigh.config 1
execute if score #active h-nigh.status matches 1.. run tellraw @s {text:'Failed To Automatic Natural Bunk Events: Cannot disable during active or pending Lunar Event.'}

function h-nigh:config/advanced/pg1