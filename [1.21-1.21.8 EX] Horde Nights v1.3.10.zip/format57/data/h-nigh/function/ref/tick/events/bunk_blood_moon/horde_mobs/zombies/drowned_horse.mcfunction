#================NOTE=================#
#All code made by RRC for Horde Nights#
#==Liscense for use per Modrinth TOS==#
#================NOTE=================#

execute store result score drowned_horse h-nigh.random run random value 1..64
execute unless score drowned_horse h-nigh.random matches 64 run tag @s add h-nigh.not_drowned_horse
execute if score drowned_horse h-nigh.random matches 64 at @s run summon zombie_horse ~ ~ ~ {PersistenceRequired:0b,Health:60f,Temper:100,SkeletonTrap:0b,Tags:["smithed.entity","smithed.strict","h-nigh.drowned_horse"],Passengers:[{id:"minecraft:drowned",Tags:["h-nigh.mob","h-nigh.not_drowned_horse"]}],active_effects:[{id:"minecraft:speed",amplifier:1,duration:24000,show_particles:1b}],attributes:[{id:"minecraft:armor",base:10},{id:"minecraft:armor_toughness",base:2},{id:"minecraft:max_health",base:60},{id:"minecraft:safe_fall_distance",base:6},{id:"minecraft:scale",base:0.4},{id:"minecraft:step_height",base:2}],SaddleItem:{id:"minecraft:saddle",Count:1b}}
execute if score drowned_horse h-nigh.random matches 64 run tp @s ~ ~-999 ~