#================NOTE=================#
#All code made by RRC for Horde Nights#
#==Liscense for use per Modrinth TOS==#
#================NOTE=================#

scoreboard objectives add rrc.init dummy
scoreboard players add h-nigh rrc.init 0
execute unless score h-nigh rrc.init matches 14 run function h-nigh:reference/init

schedule function h-nigh:reference/tellraw/load 1s